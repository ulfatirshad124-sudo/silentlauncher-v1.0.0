using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using SilentLauncher.Models;
using SilentLauncher.Services;

namespace SilentLauncher.ViewModels;

public sealed class MainViewModel : ViewModelBase
{
    private readonly StorageService _storage;
    private readonly ProcessService _procs;
    private readonly WatermarkService _watermark;
    private readonly IDialogService _dialogs;
    private readonly DispatcherTimer _statusTimer = new() { Interval = TimeSpan.FromSeconds(7) };

    private string _page = "Dashboard";
    private string _searchText = "";
    private string _statusMessage = "";
    private bool _statusIsError;
    private AppEntryViewModel? _hostedApp;

    public MainViewModel(StorageService storage, ProcessService procs, WatermarkService watermark,
                         IDialogService dialogs, AppSettings settings)
    {
        _storage = storage;
        _procs = procs;
        _watermark = watermark;
        _dialogs = dialogs;

        Settings = new SettingsViewModel(settings);
        Settings.Changed += OnSettingsChanged;

        foreach (var entry in _storage.LoadLibrary())
            AddViewModel(entry);

        AppsView = CollectionViewSource.GetDefaultView(Apps);
        AppsView.SortDescriptions.Add(new SortDescription(nameof(AppEntryViewModel.Name), ListSortDirection.Ascending));
        AppsView.Filter = o => o is AppEntryViewModel a &&
            (string.IsNullOrWhiteSpace(_searchText) || a.Name.Contains(_searchText.Trim(), StringComparison.OrdinalIgnoreCase));
        if (AppsView is ICollectionViewLiveShaping live)
        {
            live.IsLiveSorting = true;
            live.LiveSortingProperties.Add(nameof(AppEntryViewModel.Name));
        }

        Apps.CollectionChanged += OnAppsChanged;
        _procs.AppExited += (id, msg) =>
            Application.Current?.Dispatcher.BeginInvoke(new Action(() => OnAppExited(id, msg)));
        _statusTimer.Tick += (_, _) => DismissStatus();

        NavigateCommand = new RelayCommand(p => Page = p?.ToString() ?? "Dashboard");
        AddCommand = new RelayCommand(_ => AddApplications());
        LaunchCommand = new RelayCommand(p => Launch(p as AppEntryViewModel),
            p => p is AppEntryViewModel a && a.Exists && !a.IsRunning);
        EmbedCommand = new AsyncRelayCommand(p => EmbedAsync(p as AppEntryViewModel),
            p => p is AppEntryViewModel a && a.Exists && !a.IsRunning);
        CloseAppCommand = new AsyncRelayCommand(p => CloseAppAsync(p as AppEntryViewModel));
        EditCommand = new RelayCommand(p => Edit(p as AppEntryViewModel));
        RemoveCommand = new RelayCommand(p => Remove(p as AppEntryViewModel));
        ShowHostedCommand = new RelayCommand(p => ShowHosted(p as AppEntryViewModel));
        DetachCommand = new RelayCommand(_ => Detach());
        CloseHostedCommand = new AsyncRelayCommand(_ => CloseAppAsync(HostedApp));
        BackFromHostCommand = new RelayCommand(_ => Page = "Library");
        DismissStatusCommand = new RelayCommand(_ => DismissStatus());
        OpenDataFolderCommand = new RelayCommand(_ => OpenDataFolder());
        ClearLibraryCommand = new RelayCommand(_ => ClearLibrary());

        RefreshDerived();
    }

    // ---- Exposed state -------------------------------------------------------------------------------------------

    public SettingsViewModel Settings { get; }
    public ObservableCollection<AppEntryViewModel> Apps { get; } = new();
    public ICollectionView AppsView { get; }
    public IReadOnlyList<AppEntryViewModel> RecentlyAdded { get; private set; } = Array.Empty<AppEntryViewModel>();
    public IReadOnlyList<AppEntryViewModel> RecentlyOpened { get; private set; } = Array.Empty<AppEntryViewModel>();

    public IHostSurface? Host { get; set; }
    public event Action? MinimizeRequested;
    public event Action? RestoreRequested;

    public string WelcomeText => "WELCOME BACK, " + Environment.UserName.ToUpperInvariant();
    public int TotalCount => Apps.Count;
    public int RunningCount => Apps.Count(a => a.IsRunning);
    public bool IsLibraryEmpty => Apps.Count == 0;
    public bool HasRecentlyOpened => RecentlyOpened.Count > 0;
    public bool NoMatches => Apps.Count > 0 && !AppsView.Cast<object>().Any();

    public string Page
    {
        get => _page;
        set
        {
            if (!Set(ref _page, value)) return;
            OnPropertyChanged(nameof(IsDashboardPage));
            OnPropertyChanged(nameof(IsLibraryPage));
            OnPropertyChanged(nameof(IsSettingsPage));
            OnPropertyChanged(nameof(ShowSearch));
        }
    }

    public bool IsDashboardPage { get => Page == "Dashboard"; set { if (value) Page = "Dashboard"; } }
    public bool IsLibraryPage { get => Page == "Library"; set { if (value) Page = "Library"; } }
    public bool IsSettingsPage { get => Page == "Settings"; set { if (value) Page = "Settings"; } }
    public bool ShowSearch => Page is "Dashboard" or "Library";

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (!Set(ref _searchText, value)) return;
            if (!string.IsNullOrWhiteSpace(value) && Page == "Dashboard") Page = "Library";
            AppsView.Refresh();
            OnPropertyChanged(nameof(NoMatches));
        }
    }

    public AppEntryViewModel? HostedApp
    {
        get => _hostedApp;
        private set { if (Set(ref _hostedApp, value)) OnPropertyChanged(nameof(HostedAppName)); }
    }
    public string HostedAppName => HostedApp?.Name ?? "";

    public string StatusMessage { get => _statusMessage; private set { if (Set(ref _statusMessage, value)) OnPropertyChanged(nameof(HasStatus)); } }
    public bool StatusIsError { get => _statusIsError; private set => Set(ref _statusIsError, value); }
    public bool HasStatus => !string.IsNullOrEmpty(StatusMessage);

    // ---- Commands ------------------------------------------------------------------------------------------------

    public ICommand NavigateCommand { get; }
    public ICommand AddCommand { get; }
    public ICommand LaunchCommand { get; }
    public ICommand EmbedCommand { get; }
    public ICommand CloseAppCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand RemoveCommand { get; }
    public ICommand ShowHostedCommand { get; }
    public ICommand DetachCommand { get; }
    public ICommand CloseHostedCommand { get; }
    public ICommand BackFromHostCommand { get; }
    public ICommand DismissStatusCommand { get; }
    public ICommand OpenDataFolderCommand { get; }
    public ICommand ClearLibraryCommand { get; }

    // ---- Lifecycle -----------------------------------------------------------------------------------------------

    /// <summary>Called once the main window is on screen.</summary>
    public void Start()
    {
        if (Settings.StartWithWindows) StartupService.Apply(Settings.Model);
        UpdateWatermark();
    }

    public void Shutdown()
    {
        Host?.Release();
        _storage.FlushAll();
        _watermark.Dispose();
    }

    public void RefreshExistence()
    {
        foreach (var a in Apps) a.RefreshExists();
    }

    // ---- Library -------------------------------------------------------------------------------------------------

    private AppEntryViewModel AddViewModel(AppEntry entry)
    {
        var vm = new AppEntryViewModel(entry);
        vm.Changed += OnAppChanged;
        Apps.Add(vm);
        _ = vm.LoadIconAsync();
        return vm;
    }

    private void OnAppChanged()
    {
        SaveLibrary();
        UpdateWatermark();
    }

    private void OnAppsChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        RefreshDerived();
        SaveLibrary();
    }

    private void SaveLibrary() =>
        _storage.QueueSave(_storage.LibraryPath, () => Apps.Select(a => a.Model).ToList());

    private void RefreshDerived()
    {
        RecentlyAdded = Apps.OrderByDescending(a => a.Model.AddedUtc).Take(6).ToList();
        RecentlyOpened = Apps.Where(a => a.Model.LastLaunchedUtc != null)
                             .OrderByDescending(a => a.Model.LastLaunchedUtc).Take(6).ToList();
        OnPropertyChanged(nameof(RecentlyAdded));
        OnPropertyChanged(nameof(RecentlyOpened));
        OnPropertyChanged(nameof(HasRecentlyOpened));
        OnPropertyChanged(nameof(TotalCount));
        OnPropertyChanged(nameof(RunningCount));
        OnPropertyChanged(nameof(IsLibraryEmpty));
        OnPropertyChanged(nameof(NoMatches));
    }

    private void AddApplications()
    {
        var files = _dialogs.PickExecutables();
        if (files.Count == 0) return;

        int added = 0, skipped = 0;
        foreach (var file in files)
        {
            if (Apps.Any(a => string.Equals(a.ExePath, file, StringComparison.OrdinalIgnoreCase))) { skipped++; continue; }

            var draft = new AppEntry { Name = SuggestName(file), ExePath = file };
            if (files.Count == 1)
            {
                var result = _dialogs.EditApp(draft, true);
                if (result == null) return;
                draft = result;
                draft.CustomIconPath = StoreIcon(draft.Id, draft.CustomIconPath, null);
            }
            AddViewModel(draft);
            added++;
        }

        if (added > 0) { ShowStatus(added == 1 ? "Application added to your library." : $"{added} applications added.", false); Page = "Library"; }
        else if (skipped > 0) ShowStatus("That application is already in your library.", true);
        RefreshDerived();
    }

    private static string SuggestName(string path)
    {
        try
        {
            var product = FileVersionInfo.GetVersionInfo(path).ProductName?.Trim();
            if (!string.IsNullOrEmpty(product) && product.Length <= 40 && !product.Contains('®')) return product;
        }
        catch { /* fall back to file name */ }
        return Path.GetFileNameWithoutExtension(path);
    }

    private void Edit(AppEntryViewModel? app)
    {
        if (app == null) return;
        var result = _dialogs.EditApp(app.Model.Clone(), false);
        if (result == null) return;

        if (app.IsRunning && !string.Equals(result.ExePath, app.Model.ExePath, StringComparison.OrdinalIgnoreCase))
        {
            ShowStatus("Close the application before changing its executable.", true);
            return;
        }

        app.Model.Name = result.Name;
        app.Model.ExePath = result.ExePath;
        app.Model.Arguments = result.Arguments;
        app.Model.CustomIconPath = StoreIcon(app.Model.Id, result.CustomIconPath, app.Model.CustomIconPath);
        app.Touch();
        _ = app.LoadIconAsync();
        RefreshDerived();
        SaveLibrary();
    }

    private string? StoreIcon(Guid id, string? chosen, string? previous)
    {
        if (string.IsNullOrWhiteSpace(chosen)) { _storage.DeleteIcon(previous); return null; }
        if (string.Equals(chosen, previous, StringComparison.OrdinalIgnoreCase)) return previous;
        var stored = _storage.ImportIcon(id, chosen);
        if (previous != null && !string.Equals(previous, stored, StringComparison.OrdinalIgnoreCase)) _storage.DeleteIcon(previous);
        return stored;
    }

    private void Remove(AppEntryViewModel? app)
    {
        if (app == null) return;
        if (app.IsRunning) { ShowStatus($"Close \"{app.Name}\" before removing it.", true); return; }
        if (!_dialogs.Confirm("REMOVE APPLICATION", $"Remove \"{app.Name}\" from the library?\nThe program itself is not deleted.", "REMOVE")) return;
        _storage.DeleteIcon(app.Model.CustomIconPath);
        Apps.Remove(app);
    }

    private void ClearLibrary()
    {
        if (Apps.Any(a => a.IsRunning)) { ShowStatus("Close all running applications first.", true); return; }
        if (Apps.Count == 0) return;
        if (!_dialogs.Confirm("CLEAR LIBRARY", "Remove every application from the library?\nNo program files are deleted.", "CLEAR")) return;
        foreach (var a in Apps) _storage.DeleteIcon(a.Model.CustomIconPath);
        Apps.Clear();
    }

    private void OpenDataFolder()
    {
        try { Process.Start(new ProcessStartInfo { FileName = StorageService.DataDir, UseShellExecute = true }); }
        catch (Exception ex) { ShowStatus("Could not open the data folder: " + ex.Message, true); }
    }

    // ---- Launching -----------------------------------------------------------------------------------------------

    private void Launch(AppEntryViewModel? app)
    {
        if (app == null || app.IsRunning) return;
        var (p, error) = _procs.Launch(app.Model);
        if (p == null)
        {
            app.RefreshExists();
            ShowStatus(error ?? "Launch failed.", true);
            return;
        }
        MarkLaunched(app);
        ShowStatus($"{app.Name} started.", false);
        if (Settings.MinimizeOnLaunch) MinimizeRequested?.Invoke();
    }

    private async Task EmbedAsync(AppEntryViewModel? app)
    {
        if (app == null || app.IsRunning || Host == null) return;
        var (p, error) = _procs.Launch(app.Model);
        if (p == null) { app.RefreshExists(); ShowStatus(error ?? "Launch failed.", true); return; }

        MarkLaunched(app);
        ShowStatus($"Starting {app.Name} in embedded mode…", false);

        var hwnd = await WindowHostingService.WaitForMainWindowAsync(p, 12000);
        if (!app.IsRunning) return; // it already exited; OnAppExited reported why
        if (hwnd == IntPtr.Zero)
        {
            ShowStatus($"{app.Name} doesn't expose a window that can be embedded, so it keeps running in external mode.", true);
            return;
        }

        HostedApp = app;
        Page = "Host";
        await Application.Current.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.Loaded);

        if (Host.Embed(hwnd))
        {
            app.IsEmbedded = true;
            ShowStatus($"{app.Name} is running inside the launcher.", false);
        }
        else
        {
            HostedApp = null;
            Page = "Library";
            ShowStatus($"Windows would not let {app.Name} be embedded (it may run as administrator or use its own protected window). It keeps running in external mode.", true);
        }
    }

    private void MarkLaunched(AppEntryViewModel app)
    {
        app.IsRunning = true;
        app.Model.LastLaunchedUtc = DateTime.UtcNow;
        app.Model.LaunchCount++;
        app.Touch();
        SaveLibrary();
        RefreshDerived();
        UpdateWatermark();
    }

    private async Task CloseAppAsync(AppEntryViewModel? app)
    {
        if (app == null || !app.IsRunning) return;
        var error = await _procs.CloseAsync(app.Model.Id);
        if (error != null) ShowStatus(error, true);
    }

    private void OnAppExited(Guid id, string? crashMessage)
    {
        var app = Apps.FirstOrDefault(a => a.Model.Id == id);
        if (app == null) return;

        app.IsRunning = false;
        app.IsEmbedded = false;
        if (ReferenceEquals(HostedApp, app))
        {
            Host?.Release();
            HostedApp = null;
            if (Page == "Host") Page = "Library";
        }
        app.Touch();
        ShowStatus(crashMessage ?? $"{app.Name} closed.", crashMessage != null);
        if (!Apps.Any(a => a.IsRunning)) RestoreRequested?.Invoke();
        RefreshDerived();
        UpdateWatermark();
        CommandManager.InvalidateRequerySuggested();
    }

    private void ShowHosted(AppEntryViewModel? app)
    {
        if (app is { IsEmbedded: true }) { HostedApp = app; Page = "Host"; }
    }

    private void Detach()
    {
        if (HostedApp == null) return;
        Host?.Release();
        var name = HostedApp.Name;
        HostedApp.IsEmbedded = false;
        HostedApp = null;
        Page = "Library";
        ShowStatus($"{name} was detached and now runs in its own window.", false);
    }

    // ---- Settings / watermark ------------------------------------------------------------------------------------

    private void OnSettingsChanged(string property)
    {
        _storage.QueueSave(_storage.SettingsPath, () => Settings.Model);
        if (property is nameof(SettingsViewModel.StartWithWindows) or nameof(SettingsViewModel.StartMinimized) or "*")
            StartupService.Apply(Settings.Model);
        UpdateWatermark();
    }

    /// <summary>
    /// Overlay is shown when enabled, and (optionally) only while launched apps run.
    /// If any running app has its overlay switched off (e.g. it blocks overlays) the watermark is hidden.
    /// </summary>
    private void UpdateWatermark()
    {
        var running = Apps.Where(a => a.IsRunning).ToList();
        bool blocked = running.Any(a => !a.OverlayAllowed);
        bool visible = Settings.WatermarkEnabled && !blocked &&
                       (!Settings.WatermarkOnlyWhileRunning || running.Count > 0);
        _watermark.Update(Settings.Model, visible);
    }

    // ---- Status banner -------------------------------------------------------------------------------------------

    private void ShowStatus(string message, bool isError)
    {
        StatusIsError = isError;
        StatusMessage = message;
        _statusTimer.Stop();
        _statusTimer.Start();
    }

    private void DismissStatus()
    {
        _statusTimer.Stop();
        StatusMessage = "";
    }
}

using System.Windows.Media.Imaging;
using SilentLauncher.Models;
using SilentLauncher.Services;

namespace SilentLauncher.ViewModels;

public sealed class AppEntryViewModel : ViewModelBase
{
    private BitmapSource? _icon;
    private bool _exists;
    private bool _isRunning;
    private bool _isEmbedded;

    public AppEntry Model { get; }

    /// <summary>Raised when a persisted property changes (so the library gets saved).</summary>
    public event Action? Changed;

    public AppEntryViewModel(AppEntry model)
    {
        Model = model;
        _exists = File.Exists(model.ExePath);
    }

    public string Name
    {
        get => Model.Name;
        set { if (Model.Name == value) return; Model.Name = value; OnPropertyChanged(); Changed?.Invoke(); }
    }

    public string ExePath => Model.ExePath;

    public bool OverlayAllowed
    {
        get => Model.OverlayAllowed;
        set { if (Model.OverlayAllowed == value) return; Model.OverlayAllowed = value; OnPropertyChanged(); Changed?.Invoke(); }
    }

    public BitmapSource? Icon { get => _icon; private set => Set(ref _icon, value); }

    public bool Exists { get => _exists; private set { if (Set(ref _exists, value)) OnPropertyChanged(nameof(StatusText)); } }

    public bool IsRunning
    {
        get => _isRunning;
        set { if (Set(ref _isRunning, value)) OnPropertyChanged(nameof(StatusText)); }
    }

    public bool IsEmbedded
    {
        get => _isEmbedded;
        set { if (Set(ref _isEmbedded, value)) OnPropertyChanged(nameof(StatusText)); }
    }

    public string LastLaunchedText => Model.LastLaunchedUtc is { } t ? "Played " + Relative(t) : "Never launched";

    public string StatusText =>
        IsRunning ? (IsEmbedded ? "RUNNING · EMBEDDED" : "RUNNING")
        : !Exists ? "FILE MISSING"
        : LastLaunchedText;

    public void RefreshExists() => Exists = File.Exists(Model.ExePath);

    /// <summary>Call after Model fields were changed from outside (edit dialog / launch bookkeeping).</summary>
    public void Touch()
    {
        OnPropertyChanged(nameof(Name));
        OnPropertyChanged(nameof(ExePath));
        OnPropertyChanged(nameof(OverlayAllowed));
        OnPropertyChanged(nameof(LastLaunchedText));
        OnPropertyChanged(nameof(StatusText));
        RefreshExists();
    }

    /// <summary>Loads the icon off the UI thread so large libraries open instantly.</summary>
    public async Task LoadIconAsync()
    {
        var name = Model.CustomIconPath;
        var exe = Model.ExePath;
        Icon = await Task.Run(() => IconService.Load(name, exe));
    }

    private static string Relative(DateTime utc)
    {
        var d = DateTime.UtcNow - utc;
        if (d.TotalMinutes < 1) return "just now";
        if (d.TotalMinutes < 60) return $"{(int)d.TotalMinutes} min ago";
        if (d.TotalHours < 24) return $"{(int)d.TotalHours} h ago";
        if (d.TotalDays < 30) return $"{(int)d.TotalDays} d ago";
        return utc.ToLocalTime().ToString("d MMM yyyy");
    }
}

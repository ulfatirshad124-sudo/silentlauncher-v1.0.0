using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using SilentLauncher.Interop;
using SilentLauncher.Services;
using static SilentLauncher.Interop.NativeMethods;

namespace SilentLauncher.Controls;

/// <summary>
/// HwndHost that re-parents another process's top-level window into the launcher (Win32 SetParent).
/// This only works for apps that tolerate being a child window - see README for the limits.
/// Window handles are restored (un-parented, original styles) on Release() so the app is never destroyed by the launcher.
/// </summary>
public sealed class HostedAppControl : HwndHost, IHostSurface
{
    private IntPtr _host;
    private IntPtr _child;
    private long _origStyle;
    private long _origExStyle;

    protected override HandleRef BuildWindowCore(HandleRef hwndParent)
    {
        _host = CreateWindowEx(0, "static", "", (int)(WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS),
            0, 0, 0, 0, hwndParent.Handle, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
        return new HandleRef(this, _host);
    }

    protected override void DestroyWindowCore(HandleRef hwnd)
    {
        Release(); // never let DestroyWindow take the hosted app's window with it
        DestroyWindow(hwnd.Handle);
        _host = IntPtr.Zero;
    }

    public bool Embed(IntPtr hwnd)
    {
        if (_host == IntPtr.Zero || hwnd == IntPtr.Zero || !IsWindow(hwnd)) return false;
        Release();

        long style = GetLong(hwnd, GWL_STYLE);
        long exStyle = GetLong(hwnd, GWL_EXSTYLE);

        SetParent(hwnd, _host);
        if (GetParent(hwnd) != _host) return false; // blocked (different integrity level, protected window, ...)

        _origStyle = style;
        _origExStyle = exStyle;
        _child = hwnd;

        long newStyle = (style & ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX))
                        | WS_CHILD | WS_VISIBLE;
        SetLong(hwnd, GWL_STYLE, newStyle);
        SetLong(hwnd, GWL_EXSTYLE, exStyle & ~(WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE | WS_EX_APPWINDOW));
        SetWindowPos(hwnd, IntPtr.Zero, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
        ShowWindow(hwnd, SW_SHOW);
        ResizeChild();
        return true;
    }

    /// <summary>Gives the window back to the desktop with its original frame.</summary>
    public void Release()
    {
        if (_child == IntPtr.Zero) return;
        var c = _child;
        _child = IntPtr.Zero;
        try
        {
            if (!IsWindow(c)) return;
            SetParent(c, IntPtr.Zero);
            SetLong(c, GWL_STYLE, _origStyle);
            SetLong(c, GWL_EXSTYLE, _origExStyle);
            SetWindowPos(c, IntPtr.Zero, 120, 120, 1100, 700, SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW);
        }
        catch { /* window vanished while detaching */ }
    }

    protected override void OnWindowPositionChanged(Rect rcBoundingBox)
    {
        base.OnWindowPositionChanged(rcBoundingBox);
        ResizeChild((int)rcBoundingBox.Width, (int)rcBoundingBox.Height);
    }

    private void ResizeChild(int w = -1, int h = -1)
    {
        if (_child == IntPtr.Zero) return;
        if (w < 0 || h < 0)
        {
            var dpi = VisualTreeHelper.GetDpi(this);
            w = (int)(ActualWidth * dpi.DpiScaleX);
            h = (int)(ActualHeight * dpi.DpiScaleY);
        }
        MoveWindow(_child, 0, 0, Math.Max(w, 1), Math.Max(h, 1), true);
    }
}

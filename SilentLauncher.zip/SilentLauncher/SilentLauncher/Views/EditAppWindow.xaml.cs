using System.Windows;
using System.Windows.Input;
using Microsoft.Win32;
using SilentLauncher.Models;
using SilentLauncher.Services;

namespace SilentLauncher.Views;

public partial class EditAppWindow : Window
{
    private readonly AppEntry _draft;
    private string? _iconPath;

    /// <summary>Edited copy of the entry (null until SAVE succeeds).</summary>
    public AppEntry? Result { get; private set; }

    public EditAppWindow(AppEntry draft, bool isNew)
    {
        InitializeComponent();
        _draft = draft;
        Heading.Text = isNew ? "ADD APPLICATION" : "EDIT APPLICATION";
        NameBox.Text = draft.Name;
        PathBox.Text = draft.ExePath;
        ArgsBox.Text = draft.Arguments ?? "";
        _iconPath = draft.CustomIconPath;
        RefreshPreview();
        Loaded += (_, _) => { NameBox.Focus(); NameBox.SelectAll(); };
    }

    private void RefreshPreview() => PreviewImage.Source = IconService.Load(_iconPath, PathBox.Text);

    private void Header_MouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Title = "Select application", Filter = "Applications (*.exe)|*.exe", CheckFileExists = true };
        if (dlg.ShowDialog(this) != true) return;
        PathBox.Text = dlg.FileName;
        RefreshPreview();
    }

    private void ChooseIcon_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Title = "Choose an icon image",
            Filter = "Images (*.png;*.jpg;*.jpeg;*.bmp;*.ico)|*.png;*.jpg;*.jpeg;*.bmp;*.ico",
            CheckFileExists = true
        };
        if (dlg.ShowDialog(this) != true) return;
        _iconPath = dlg.FileName;
        RefreshPreview();
    }

    private void ResetIcon_Click(object sender, RoutedEventArgs e)
    {
        _iconPath = null;
        RefreshPreview();
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        var name = NameBox.Text.Trim();
        if (name.Length == 0) { ShowError("Please enter a name."); return; }
        if (!File.Exists(PathBox.Text)) { ShowError("That executable doesn't exist. Use BROWSE to locate it."); return; }
        if (!PathBox.Text.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) { ShowError("Only .exe files can be added."); return; }

        var copy = _draft.Clone();
        copy.Name = name;
        copy.ExePath = PathBox.Text;
        copy.Arguments = string.IsNullOrWhiteSpace(ArgsBox.Text) ? null : ArgsBox.Text.Trim();
        copy.CustomIconPath = _iconPath;
        Result = copy;
        DialogResult = true;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }
}

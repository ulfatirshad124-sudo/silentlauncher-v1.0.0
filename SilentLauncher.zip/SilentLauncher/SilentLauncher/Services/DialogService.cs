using Microsoft.Win32;
using System.Windows;
using SilentLauncher.Models;
using SilentLauncher.Views;

namespace SilentLauncher.Services;

public interface IDialogService
{
    IReadOnlyList<string> PickExecutables();
    AppEntry? EditApp(AppEntry draft, bool isNew);
    bool Confirm(string title, string message, string confirmText = "CONFIRM");
}

public sealed class DialogService : IDialogService
{
    private static Window? Owner => Application.Current?.MainWindow;

    public IReadOnlyList<string> PickExecutables()
    {
        var dlg = new OpenFileDialog
        {
            Title = "Select application(s) to add",
            Filter = "Applications (*.exe)|*.exe",
            Multiselect = true,
            CheckFileExists = true
        };
        return dlg.ShowDialog(Owner) == true ? dlg.FileNames : Array.Empty<string>();
    }

    public AppEntry? EditApp(AppEntry draft, bool isNew)
    {
        var w = new EditAppWindow(draft, isNew) { Owner = Owner };
        return w.ShowDialog() == true ? w.Result : null;
    }

    public bool Confirm(string title, string message, string confirmText = "CONFIRM")
    {
        var w = new ConfirmWindow(title, message, confirmText) { Owner = Owner };
        return w.ShowDialog() == true;
    }
}

using SilentLauncher.Models;
using SilentLauncher.Views;

namespace SilentLauncher.Services;

public sealed class WatermarkService : IDisposable
{
    private WatermarkWindow? _window;

    public void Update(AppSettings settings, bool visible)
    {
        if (!visible)
        {
            _window?.HideOverlay();
            return;
        }
        _window ??= new WatermarkWindow();
        _window.Apply(settings);
        _window.ShowOverlay();
    }

    public void Dispose()
    {
        try { _window?.Close(); } catch { /* shutting down */ }
        _window = null;
    }
}

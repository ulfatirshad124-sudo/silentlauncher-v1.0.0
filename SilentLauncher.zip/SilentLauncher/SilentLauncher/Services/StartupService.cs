using Microsoft.Win32;
using SilentLauncher.Models;

namespace SilentLauncher.Services;

/// <summary>"Start with Windows" via the per-user Run registry key (no admin rights needed).</summary>
public static class StartupService
{
    private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "SilentLauncher";

    public static void Apply(AppSettings s)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunKey, writable: true);
            if (key == null) return;
            if (s.StartWithWindows && Environment.ProcessPath is { } exe)
                key.SetValue(ValueName, $"\"{exe}\"" + (s.StartMinimized ? " --minimized" : ""));
            else
                key.DeleteValue(ValueName, throwOnMissingValue: false);
        }
        catch (Exception ex) { Log.Error("Could not update startup entry", ex); }
    }
}

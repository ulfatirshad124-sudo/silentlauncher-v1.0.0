namespace SilentLauncher.Services;

/// <summary>Abstraction over the embedded-window host so view models don't depend on WPF controls.</summary>
public interface IHostSurface
{
    bool Embed(IntPtr hwnd);
    void Release();
}

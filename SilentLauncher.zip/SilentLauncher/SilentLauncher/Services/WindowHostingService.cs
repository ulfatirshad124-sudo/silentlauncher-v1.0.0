using System.Diagnostics;

namespace SilentLauncher.Services;

public static class WindowHostingService
{
    /// <summary>
    /// Waits until the process exposes a stable top-level main window. Returns IntPtr.Zero if it never does
    /// (console apps, tray apps, games that create their window late, launcher stubs that spawn another process...).
    /// </summary>
    public static async Task<IntPtr> WaitForMainWindowAsync(Process p, int timeoutMs)
    {
        var sw = Stopwatch.StartNew();
        IntPtr last = IntPtr.Zero;
        int stable = 0;
        while (sw.ElapsedMilliseconds < timeoutMs)
        {
            try
            {
                if (p.HasExited) return IntPtr.Zero;
                p.Refresh();
                var h = p.MainWindowHandle;
                if (h != IntPtr.Zero)
                {
                    if (h == last) { if (++stable >= 3) return h; }
                    else { last = h; stable = 0; }
                }
            }
            catch { return IntPtr.Zero; }
            await Task.Delay(250);
        }
        return last;
    }
}

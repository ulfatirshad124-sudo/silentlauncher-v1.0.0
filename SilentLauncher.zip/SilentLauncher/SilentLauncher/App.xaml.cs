using System.Windows;
using System.Windows.Threading;
using SilentLauncher.Services;
using SilentLauncher.ViewModels;
using SilentLauncher.Views;

namespace SilentLauncher;

public partial class App : Application
{
    private Mutex? _mutex;
    private MainViewModel? _viewModel;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // One instance only: avoids two watermarks / two libraries fighting over the same JSON files.
        _mutex = new Mutex(true, @"Local\SilentLauncher.SingleInstance", out bool created);
        if (!created)
        {
            MessageBox.Show("SILENT LAUNCHER is already running.", "SILENT LAUNCHER",
                MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();
            return;
        }

        DispatcherUnhandledException += OnUnhandledException;

        var storage = new StorageService();
        var settings = storage.LoadSettings();
        ThemeService.ApplyAccent(settings.AccentColor);

        _viewModel = new MainViewModel(storage, new ProcessService(), new WatermarkService(), new DialogService(), settings);
        var window = new MainWindow { DataContext = _viewModel };
        MainWindow = window;

        bool startMinimized = e.Args.Contains("--minimized", StringComparer.OrdinalIgnoreCase);
        if (startMinimized) window.WindowState = WindowState.Minimized;
        window.Show();

        _viewModel.Start();
    }

    private void OnUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        Log.Error("Unhandled UI exception", e.Exception);
        MessageBox.Show("Something went wrong, but SILENT LAUNCHER kept running.\n\n" + e.Exception.Message +
                        "\n\nDetails were written to %AppData%\\SilentLauncher\\log.txt",
            "SILENT LAUNCHER", MessageBoxButton.OK, MessageBoxImage.Warning);
        e.Handled = true;
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try { _viewModel?.Shutdown(); } catch (Exception ex) { Log.Error("Shutdown error", ex); }
        try { _mutex?.ReleaseMutex(); } catch { /* not owned */ }
        _mutex?.Dispose();
        base.OnExit(e);
    }
}

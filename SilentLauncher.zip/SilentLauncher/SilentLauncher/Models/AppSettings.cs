namespace SilentLauncher.Models;

public enum WatermarkPosition { TopRight, TopLeft, BottomRight, BottomLeft }

public sealed class AppSettings
{
    public string AccentColor { get; set; } = "#FF0000";

    public bool WatermarkEnabled { get; set; } = true;
    public double WatermarkFontSize { get; set; } = 12;
    public double WatermarkOpacity { get; set; } = 0.85;
    public WatermarkPosition WatermarkPosition { get; set; } = WatermarkPosition.TopRight;
    /// <summary>Only show the overlay while an app launched from SILENT LAUNCHER is running.</summary>
    public bool WatermarkOnlyWhileRunning { get; set; } = true;

    public bool StartWithWindows { get; set; }
    public bool StartMinimized { get; set; }
    public bool MinimizeOnLaunch { get; set; } = true;
}
